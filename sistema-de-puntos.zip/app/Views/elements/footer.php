<footer class="text-muted py-5">
    <div class="container">
        <p class="mb-1">&copy; 2022 Made with ❤ by <a href="https://github.com/arthur-guevara">Arthur</a></p>
    </div>
</footer>